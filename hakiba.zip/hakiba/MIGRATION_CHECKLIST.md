# CSMS Migration Checklist

Use this checklist to ensure a complete and successful migration of the CSMS system to your new VPS.

## 📋 Pre-Migration Checklist

### System Requirements
- [ ] PostgreSQL 15+ installed and configured
- [ ] Node.js 18+ installed
- [ ] Java 17+ installed
- [ ] Maven 3.6+ installed
- [ ] Git installed (for source code)
- [ ] Sufficient disk space (minimum 2GB recommended)

### Network & Security
- [ ] Firewall configured to allow ports 8080 (backend) and 9002 (frontend)
- [ ] SSL certificates ready (if using HTTPS)
- [ ] Domain name configured (if applicable)
- [ ] Backup strategy planned

## 🗄️ Database Migration

### Step 1: Database Setup
- [ ] PostgreSQL service running
- [ ] Database user 'postgres' created with password 'password'
- [ ] Database 'prizma' created
- [ ] Database permissions granted

### Step 2: Data Restoration
- [ ] Database backup files copied to server
- [ ] `prizma_complete.sql` restored successfully
- [ ] Data verification completed (users, employees, institutions)
- [ ] Database connection tested

### Step 3: Prisma Setup
- [ ] Prisma schema files copied
- [ ] Prisma migrations copied
- [ ] Prisma client generated
- [ ] Migration status verified

## 🖥️ Application Deployment

### Frontend Setup
- [ ] Source code cloned/copied to server
- [ ] Node modules installed (`npm install`)
- [ ] Environment file configured (`.env`)
- [ ] Database URL updated in environment
- [ ] Prisma client generated
- [ ] Build completed successfully (`npm run build`)
- [ ] Development server starts without errors

### Backend Setup
- [ ] Java application copied to server
- [ ] Maven dependencies resolved (`mvn clean install`)
- [ ] Database configuration updated (`application.properties`)
- [ ] Database connection verified
- [ ] Application starts without errors (`mvn spring-boot:run`)
- [ ] API endpoints accessible

## 🔧 Configuration Updates

### Database Credentials Update
- [ ] Frontend `.env` updated with new database URL
- [ ] Backend `application.properties` updated
- [ ] Prisma schema connection verified
- [ ] Environment variables secured

### Security Configuration
- [ ] Default passwords changed
- [ ] JWT secret key updated
- [ ] NextAuth secret configured
- [ ] File upload directory permissions set
- [ ] Database access restricted

### API Configuration
- [ ] CORS settings updated for new domain
- [ ] API endpoints tested
- [ ] File upload endpoints working
- [ ] Authentication flow verified

## 🧪 Testing & Verification

### Basic Functionality
- [ ] Frontend loads at correct URL
- [ ] Backend API responds at `/api` endpoints
- [ ] Database connection stable
- [ ] User authentication working

### User Account Testing
- [ ] Admin login successful
- [ ] HRO user login successful  
- [ ] Employee user login successful
- [ ] Password reset functionality working
- [ ] User role permissions verified

### Core Features Testing
- [ ] Employee management working
- [ ] HR request submission working
- [ ] Request approval workflow working
- [ ] File upload functionality working
- [ ] Notification system working
- [ ] Reporting features accessible

### Data Integrity Verification
- [ ] User count matches original (159 users)
- [ ] Employee count matches original (151 employees)
- [ ] Institution count matches original (41 institutions)
- [ ] HR requests preserved
- [ ] Employee certificates preserved

## 🚀 Production Deployment

### Performance Optimization
- [ ] Database indexes verified
- [ ] Application performance tested
- [ ] Memory usage monitored
- [ ] Log levels configured appropriately

### Monitoring Setup
- [ ] Application logs configured
- [ ] Database monitoring enabled
- [ ] Error tracking implemented
- [ ] Backup automation configured

### Final Checks
- [ ] All URLs and endpoints working
- [ ] SSL certificates installed (if applicable)
- [ ] Domain name resolving correctly
- [ ] User training materials updated
- [ ] Documentation updated with new server details

## 📞 Post-Migration Tasks

### User Communication
- [ ] Users notified of new system URL
- [ ] Login credentials communicated
- [ ] Training scheduled if needed
- [ ] Support documentation updated

### Maintenance Setup
- [ ] Regular backup schedule configured
- [ ] Update procedures documented
- [ ] Monitoring alerts configured
- [ ] Emergency procedures documented

## ⚠️ Rollback Plan

In case of migration issues:
- [ ] Original system backup verified
- [ ] Rollback procedure documented
- [ ] Database restore tested
- [ ] User communication plan ready

## 📊 Migration Success Criteria

The migration is considered successful when:
- [ ] All 159 users can log in successfully
- [ ] All 8 HR request types function correctly
- [ ] File uploads work for all document types
- [ ] Workflow approvals process correctly
- [ ] Reports generate without errors
- [ ] System performance meets requirements
- [ ] All test cases pass

---

**Migration Date**: _______________  
**Migrated By**: _______________  
**Verification Completed By**: _______________  
**Production Go-Live Date**: _______________