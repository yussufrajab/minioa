# CSMS Database Backup & Restoration Guide

This directory contains everything needed to restore the Civil Service Management System (CSMS) to a new VPS environment.

## 📋 What's Included

- `prizma_complete.sql` - Full database backup with schema and data
- `prizma_data.sql` - Data-only backup
- `prizma_schema.sql` - Schema-only backup
- `prisma/` - Prisma schema and migration files
- `restore_csms.sh` - Automated restoration script
- `.env.example` - Frontend environment configuration template
- `application.properties.example` - Backend configuration template

## 🔧 Prerequisites for New VPS

1. **PostgreSQL 15+** installed and running
2. **Node.js 18+** and npm installed
3. **Java 17+** and Maven installed
4. **Git** for cloning the source code

## 🚀 Quick Restoration (Automated)

1. Copy this entire `hakiba` directory to your new VPS
2. Make the script executable: `chmod +x restore_csms.sh`
3. Run the restoration: `./restore_csms.sh`
4. Follow the post-installation steps below

## 📝 Manual Restoration Steps

### Step 1: Database Setup

```bash
# Create PostgreSQL user and database
sudo -u postgres psql
CREATE USER postgres WITH PASSWORD 'password';
CREATE DATABASE prizma OWNER postgres;
GRANT ALL PRIVILEGES ON DATABASE prizma TO postgres;
\q

# Restore the database
psql -h localhost -U postgres -d prizma -f prizma_complete.sql
```

### Step 2: Verify Database

```bash
# Check if data was restored correctly
psql -h localhost -U postgres -d prizma -c "SELECT COUNT(*) FROM \"User\";"
psql -h localhost -U postgres -d prizma -c "SELECT COUNT(*) FROM \"Employee\";"
psql -h localhost -U postgres -d prizma -c "SELECT COUNT(*) FROM \"Institution\";"
```

### Step 3: Setup Application Code

```bash
# Clone or copy your CSMS source code
git clone <your-csms-repository> csms
cd csms

# Copy configuration files
cp hakiba/.env.example frontend/.env
cp hakiba/application.properties.example backend/src/main/resources/application.properties

# Copy Prisma files (if not already in source)
cp -r hakiba/prisma/* frontend/prisma/
```

### Step 4: Frontend Setup

```bash
cd frontend
npm install
npx prisma generate
npm run build
npm run dev  # Starts on port 9002
```

### Step 5: Backend Setup

```bash
cd backend
mvn clean install
mvn spring-boot:run  # Starts on port 8080
```

## 🔍 Database Information

- **Original Database**: `prizma` (Mamlaka2020)
- **New Database**: `prizma` (password)
- **Host**: localhost
- **Port**: 5432
- **Connection String**: `postgresql://postgres:password@localhost:5432/prizma`

## 👥 Test User Accounts

All user accounts have the default password: `password123`

| Role | Username | Description |
|------|----------|-------------|
| ADMIN | admin | System administrator |
| HRO | hro_user | HR Officer (institution-specific) |
| HRMO | hrmo_user | HR Management Officer |
| HHRMD | hhrmd_user | Head of HR Management |
| DO | do_user | Disciplinary Officer |
| EMPLOYEE | employee_user | Basic employee |
| CSCS | cscs_user | Civil Service Commission Secretary |
| HRRP | hrrp_user | HR Responsible Personnel |
| PO | po_user | Planning Officer (read-only) |

## 🏗️ Architecture Overview

### Frontend (Next.js)
- **Port**: 9002
- **Framework**: Next.js 15 with TypeScript
- **Database**: Prisma ORM
- **Styling**: Tailwind CSS
- **Authentication**: NextAuth.js

### Backend (Spring Boot)
- **Port**: 8080
- **Framework**: Spring Boot 3.1.5 (Java 17)
- **Database**: JPA/Hibernate
- **API**: REST endpoints under `/api/*`
- **Authentication**: JWT tokens

### Database (PostgreSQL)
- **Version**: PostgreSQL 15
- **Name**: `prizma`
- **Tables**: 15+ tables for users, employees, requests, etc.

## 🔐 Security Notes

1. **Change Default Passwords**: Update all default passwords before production use
2. **Environment Variables**: Update `.env` files with secure values
3. **JWT Secret**: Generate a new JWT secret for production
4. **Database Access**: Restrict database access to application servers only
5. **File Uploads**: Configure proper file upload restrictions

## 🧪 Testing the Installation

1. **Database Connection**: Check if both frontend and backend can connect to database
2. **User Login**: Test login with default credentials
3. **API Endpoints**: Verify backend API is accessible at `http://localhost:8080/api`
4. **Frontend**: Verify frontend loads at `http://localhost:9002`
5. **File Uploads**: Test document upload functionality

## 🐛 Troubleshooting

### Database Issues
- Ensure PostgreSQL is running: `sudo systemctl status postgresql`
- Check database exists: `psql -U postgres -l`
- Verify connection: `psql -h localhost -U postgres -d prizma`

### Backend Issues
- Check Java version: `java -version` (should be 17+)
- Verify Maven: `mvn -version`
- Check logs: `tail -f backend/logs/csms.log`

### Frontend Issues
- Check Node version: `node -v` (should be 18+)
- Verify Prisma: `npx prisma --version`
- Check build: `npm run build`

### Common Error Solutions

1. **"Database does not exist"**: Run `CREATE DATABASE prizma;`
2. **"Password authentication failed"**: Check password in configuration files
3. **"Port already in use"**: Kill existing processes or change ports
4. **"Prisma client not generated"**: Run `npx prisma generate`

## 📞 Support

For technical support or questions about this backup:
- Check the main CLAUDE.md file in the project root
- Review the comprehensive documentation in the project
- Ensure all prerequisites are met before installation

## 📊 System Statistics

The backup includes:
- 159 users across 9 different roles
- 151 employees from various government institutions
- 41 government institutions/ministries
- Complete HR request system with 8 request types
- Fully configured workflow system

---

**Last Updated**: July 2025  
**Backup Source**: Windows Development Environment  
**Target Environment**: Linux VPS with PostgreSQL