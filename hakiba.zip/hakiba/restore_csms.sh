#!/bin/bash

# CSMS Database Restoration Script for New VPS
# This script restores the Civil Service Management System database to a new environment
# 
# Prerequisites:
# 1. PostgreSQL 15+ installed
# 2. Node.js 18+ installed
# 3. User 'postgres' with password 'password' configured
# 4. Database name should be 'prizma'

set -e  # Exit on any error

echo "=== CSMS Database Restoration Script ==="
echo "Starting restoration process..."

# Configuration for new VPS
NEW_DB_HOST="localhost"
NEW_DB_USER="postgres"
NEW_DB_PASSWORD="password"
NEW_DB_NAME="prizma"
NEW_DB_PORT="5432"

# Export password for PostgreSQL commands
export PGPASSWORD="$NEW_DB_PASSWORD"

echo "Step 1: Creating database '$NEW_DB_NAME' if it doesn't exist..."
psql -h "$NEW_DB_HOST" -U "$NEW_DB_USER" -p "$NEW_DB_PORT" -c "CREATE DATABASE $NEW_DB_NAME;" 2>/dev/null || echo "Database already exists, continuing..."

echo "Step 2: Restoring database schema and data..."
psql -h "$NEW_DB_HOST" -U "$NEW_DB_USER" -p "$NEW_DB_PORT" -d "$NEW_DB_NAME" -f "./prizma_complete.sql"

echo "Step 3: Verifying database connection..."
psql -h "$NEW_DB_HOST" -U "$NEW_DB_USER" -p "$NEW_DB_PORT" -d "$NEW_DB_NAME" -c "SELECT COUNT(*) as total_users FROM \"User\";"
psql -h "$NEW_DB_HOST" -U "$NEW_DB_USER" -p "$NEW_DB_PORT" -d "$NEW_DB_NAME" -c "SELECT COUNT(*) as total_employees FROM \"Employee\";"
psql -h "$NEW_DB_HOST" -U "$NEW_DB_USER" -p "$NEW_DB_PORT" -d "$NEW_DB_NAME" -c "SELECT COUNT(*) as total_institutions FROM \"Institution\";"

echo "Step 4: Setting up Prisma environment..."
if [ -d "./prisma" ]; then
    echo "Prisma directory found, proceeding with setup..."
    
    # Create .env file for new environment
    cat > .env << EOF
# Database Configuration for New VPS
DATABASE_URL="postgresql://$NEW_DB_USER:$NEW_DB_PASSWORD@$NEW_DB_HOST:$NEW_DB_PORT/$NEW_DB_NAME"

# Application Settings
NEXTAUTH_SECRET="your-secret-key-here-change-this"
NEXTAUTH_URL="http://localhost:9002"

# Backend API Configuration
NEXT_PUBLIC_API_URL="http://localhost:8080/api"
EOF

    echo "Environment file created successfully."
    
    echo "Step 5: Installing Prisma dependencies..."
    npm install prisma @prisma/client
    
    echo "Step 6: Generating Prisma client..."
    npx prisma generate
    
    echo "Step 7: Verifying Prisma migrations..."
    npx prisma migrate status
    
else
    echo "Warning: Prisma directory not found. Please copy the prisma folder manually."
fi

echo ""
echo "=== Database Restoration Complete ==="
echo ""
echo "Database Information:"
echo "  Host: $NEW_DB_HOST"
echo "  Port: $NEW_DB_PORT"
echo "  Database: $NEW_DB_NAME"
echo "  User: $NEW_DB_USER"
echo "  Password: $NEW_DB_PASSWORD"
echo ""
echo "Connection String:"
echo "  postgresql://$NEW_DB_USER:$NEW_DB_PASSWORD@$NEW_DB_HOST:$NEW_DB_PORT/$NEW_DB_NAME"
echo ""
echo "Next Steps:"
echo "1. Copy your frontend and backend code to the new VPS"
echo "2. Update backend application.properties with new database credentials"
echo "3. Update frontend .env with the DATABASE_URL shown above"
echo "4. Start backend: cd backend && mvn spring-boot:run"
echo "5. Start frontend: cd frontend && npm run dev"
echo ""
echo "Test Users (default password: password123):"
echo "  Admin: admin"
echo "  HRO: hro_user"
echo "  HRMO: hrmo_user"
echo "  Employee: employee_user"
echo ""