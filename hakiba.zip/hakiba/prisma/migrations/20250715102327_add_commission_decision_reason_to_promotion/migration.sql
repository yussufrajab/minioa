-- AlterTable
ALTER TABLE "PromotionRequest" ADD COLUMN "commissionDecisionReason" TEXT;